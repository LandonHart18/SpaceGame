# SpaceGame

You and your pair programming teammate have been hired by a firm to provide a console-based prototype of a space game. Based on product owner requirements, spend the next few days implementing a space game where you travel from planet to planet (not less than 5 planets) buying and selling goods.
 

Requirements: a class library project that will be consumed by the console app project and a test project

Deliverables:

-An algorithm,

-IPO chart (Input, Process, Output), 

-Mockup depicting the output to the screen,

-Flowchart depicting the flow of the program, 

-Classes with method stubs and properties via a class diagram,

-Use cases or test method stubs,

-A list of assignments per team member with dates to be completed by

Your directory structure should be laid out as follows. Files listed represent a minimum set of included files; you will have more that aren't listed. Your submission should be a single ZIP archive created with git archive or Github's ZIP download.

.
|- code/
|  |- PROJECT.sln
|
|- docs/
|  |- requirements.md
|
|- README.md
