using Microsoft.VisualStudio.TestTools.UnitTesting;
using SpaceGame;
using SpaceGameLibrary;


namespace SpaceGameTest
{
    [TestClass]
    public class UnitTest1
    {
        //Test beginning of the game.
        [TestMethod]
        void TestMethod1()
        {
            Dialogue dialogue = new Dialogue();
            Writer writer = new Writer();
            writer.Start();
            Assert.AreEqual("hello", dialogue.Start());
        }
    }
}
