﻿using System;
using System.Collections.Generic;
using System.Text;
using SpaceGameLibrary;


namespace SpaceGame
{
    public class Writer
    {
        Dialogue dialogue = new Dialogue();

        /// <summary>
        /// Accesses the dialogue to put in proper display format.  Methods are called by the controller. -Aaron
        /// </summary>

        public void Start()
        {            
            Console.WriteLine(dialogue.Title);
        }
    }
}
