﻿using System;
using SpaceGameLibrary;

namespace SpaceGame
{
    class Program
    {

        static void Main()
        {
            Combat combat = new Combat();
            combat.FightMenu();
            Controller controller = new Controller();
            
            controller.Start();
        }
    }
}
