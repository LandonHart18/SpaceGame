﻿using System;
using System.Collections.Generic;
using System.Text;
using SpaceGameLibrary;

namespace SpaceGame
{
    class Controller
    {
        Writer writer = new Writer();

        /// <summary>
        ///This will control all the logic to move from one screen to the next.  All player input will go through here. -Aaron
        /// </summary>
        
        public void Start()
        {
            writer.Start();
        }

    }
}
