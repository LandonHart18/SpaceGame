﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
     class Mercury : Planet
    {
        Random random = new Random();
        public Mercury()
        {
            Random random = new Random();
            this.PopulationInfluence = random.Next(20, 51);
        }
        public void MercuryShop()
        {
            Store store = new Store();
            int storeSellPrice = PopulationInfluence;
            store.Food("buy", storeSellPrice, 0);
        }
    }
}
