﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace SpaceGame
{
    class Mars : Planet
    {
        int PopulationInfluence{get;set;}
        public Mars()
        {
            Random random = new Random();
            this.PopulationInfluence = random.Next(60,81);
        }
        public void MarsShop()
        {
            Store store = new Store();
            int storeSellPrice = PopulationInfluence;
            store.Food("buy", storeSellPrice,0);
        }

        
        

    }
}
