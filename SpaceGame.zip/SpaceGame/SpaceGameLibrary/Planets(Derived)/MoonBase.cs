﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    class MoonBase : Planet
    {
        public MoonBase()
        {
            Random random = new Random();
            this.PopulationInfluence = random.Next(20, 51);
        }
        public void Shop()
        {
            Store store = new Store();
            int storeSellPrice = PopulationInfluence;
           // store.Upgrades("buy", storeSellPrice, 0);
        }
    }
}
