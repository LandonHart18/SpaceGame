﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    class Titan : Planet
    {
        public Titan()
        {
            Random random = new Random();
            this.PopulationInfluence = random.Next(20, 51);
        }
        public void Shop()
        {
            Store store = new Store();
            int storeSellPrice = PopulationInfluence;
            store.Food("buy", storeSellPrice, 0);
        }
    }
}
