﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace SpaceGame
{
    class Earth : Planet
    {
        public Earth()
        {
            
        }
        public void Shop(int item)
        {
            Random random = new Random();
            Store store = new Store();
            if(item == 1)
            {
                int storeBuyPrice = random.Next(70,91);
                store.Food("sell", 0, storeBuyPrice);
            }    
            else if (item ==2)
            {
                int storeBuyPrice = random.Next(80, 101);
                store.Aphrodisiac("sell", 0, storeBuyPrice);
            }
            else if (item == 3)
            {
                int storeBuyPrice = random.Next(100,131);
                store.Metals("sell", 0, storeBuyPrice);
            }
            else if (item == 4)
            {
                int storeBuyPrice = random.Next(90, 161);
                store.Water("sell", 0, storeBuyPrice);
            }
            else if (item == 5)
            {
                int storeBuyPrice = random.Next(1, 11);
                store.Fuel("sell", 0, storeBuyPrice);
            }
            
        }

    }
}
