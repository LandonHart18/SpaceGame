﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    class Venus : Planet
    {
        public Venus()
        {
            Random random = new Random();
            this.PopulationInfluence = random.Next(60, 91);
        }
        public void Shop()
        {
            Store store = new Store();
            int storeSellPrice = PopulationInfluence;
            store.Aphrodisiac("buy", storeSellPrice, 0);
        }
    }
}
