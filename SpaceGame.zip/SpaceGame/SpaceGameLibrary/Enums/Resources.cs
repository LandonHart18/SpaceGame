﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    enum Resources
    {
        Credits = 1,
        Fuel = 2,
        Food = 3,
        Water = 4,
        Metals = 5,
        Aphrodisiac = 6
    }
}
