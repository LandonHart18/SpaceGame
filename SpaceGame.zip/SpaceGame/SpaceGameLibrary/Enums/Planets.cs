﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGameLibrary
{
    enum Planets 
    {
        Mercury = 1, 
        Venus = 2, 
        Earth = 3, 
        MoonBase = 4, 
        Mars = 5, 
        Europa = 6, 
        Titan = 7 
    }    
}