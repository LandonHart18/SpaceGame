﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    public class Ships
    {
        //Enter all ship properties for Player and Pirate Ships.
        public int HitPoints { get; set; }
        public int Weapon { get; set; }
        public int Shield { get; set; }
        public int Engine { get; set; } 
    }
}
