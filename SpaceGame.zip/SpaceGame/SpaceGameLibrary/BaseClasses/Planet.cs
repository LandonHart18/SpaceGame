﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Security.Permissions;
using System.Text;

namespace SpaceGame
{    
    class Planet
    {
        
        //Enter all input for the planet.  Create inherited classes for each planet        
        public int PopulationInfluence { get; set; }

        public int PlanetPoint { get; set; }

        public int PlanetResource { get; set; }

        public int FarmableResource { get; set; }

        public void CalculatePlanetResource(int PopulationInfluence, int PlanetResource)
        {
            FarmableResource = PopulationInfluence * PlanetResource;            
        }

        /* public void Shop()
         {
             PlayerShip ship = new PlayerShip();
             Random random = new Random();
             Store store = new Store();
             //Check total price vs cost and storage.
             switch (Playership.PlanetPoint)
             {
                 case 1:
                     //Placeholder text for Mercury

                 int storeSellPrice= random.Next(90,121)

                     Console.WriteLine("Hello welcome to Murcury, Would you like to see my wares?\n1.Browse Goods\n2.HarrasShopKeeper "+
                         "\n3.Leave");
                     int i = int.Parse(Console.ReadLine());

                     switch(i)
                         {
                         case 1:
                             store.Shop(storeSellPrice, storeBuyPrice);
                             break;
                         case 2:
                             break;
                         case 3:
                             break;
                         default:
                             Console.WriteLine("The man seems upset");
                             break;


                     }
                     //inventory stuff for Murcury
                     break;


                 case 2:
                     //inventory stuff
                       //Venus Aphrodisiacs
                     break;

                 case 3:
                     //Earth buys

         switch(what good they are selling)
        case1(metals)
        int storeBuyPrice= random.Next(100,121)



                    break;


                 case 4:
                     //Mars Food
                    break;


                 case 5:
                    // Moon base Upgrade
                     break;

                 case 6:
                     //Titan Water 
                     break;


                 case 7:
                     //Europa sells everything
                    break;

                default:
                     break;
             }

         }*/


    }
}
