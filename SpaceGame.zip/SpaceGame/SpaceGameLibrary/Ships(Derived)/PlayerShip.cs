﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace SpaceGame
{
    public class PlayerShip : Ships
    {
        /// <summary>
        /// All player input needs to be moved to the Controller otherwise there will be a disconnect in display. -Aaron
        /// </summary>
        
        //Assign additional properties.

        public int Crew { get; set; }
        public bool CanFly { get; set; }

        //Planet
        public int CurrentPoint { get; set; }
        public int DestinationPoint { get; set; }
        //currency
        public int SpaceBucks { get; set; }
        //fuel
        public int Fuel { get; set; }
        public int FuelSpaceAvailable { get; }
        public int MaxFuel { get; set; }
        //goods
        public int FoodGoods{get;set;}
        public int WaterGoods{get;set;}
        public int AphrodisiacGoods{get;set;}
        public int MetalsGoods{get;set;}
        public int MaxCargo { get; set; }
        public int UsedCargoSpace { get; set; }
        public int StorageSpace { get; }
        public int MaxHitPoints { get; set; }
        public int Repair { get; set; }
        public int ShieldQuantity { get; set; } //how many times you can activate shield
        public int ShieldMaxPower { get; set; } // how much damage the shield will absorb
        public int RepairValue { get; set; }
        

        //Set default values.
        public PlayerShip()
        {
            this.HitPoints = 100;

            this.MaxHitPoints = 100;

            this.Repair = 1;

            this.RepairValue = 10;

            this.Weapon = 1;

            this.Shield = 0;

            this.ShieldQuantity = 1;

            this.ShieldMaxPower = 10;

            this.Engine = 1;

            this.Fuel = 0;

            this.MaxFuel = 20;

            this.Crew = 2;

            this.UsedCargoSpace = CalculateStorage();

            this.MaxCargo = 10;

            this.CurrentPoint = 3;

            this.SpaceBucks = 20;

            this.CanFly = false;

            this.StorageSpace = MaxCargo - UsedCargoSpace;

            this.FuelSpaceAvailable = MaxFuel - Fuel;

            this.FoodGoods = 0;

            this.WaterGoods = 0;

            this.AphrodisiacGoods=0;

            this.MetalsGoods = 0;
        }

        public int CalculateStorage()
        {
            int inventory = FoodGoods + WaterGoods + AphrodisiacGoods + MetalsGoods;
            return inventory;
        }

        //verify if the player can purchase goods/fuel
        public int CanBuy(string type,int ammountSelected, int shopPrice)
        {
            int totalPrice =(ammountSelected * shopPrice);
            //goods
            if (type == "goods")
            {

                //get total price
                

                //return for player having too little curency
                if (totalPrice > SpaceBucks)
                    return 1;

                //return for player not having enough storage space
                else if (ammountSelected > StorageSpace)
                    return 2;

                //return for player having enough currency and storage space
                else if (totalPrice <= SpaceBucks && ammountSelected <= StorageSpace)
                    return 3;
                //Something went wrong return a 4 to deny player from purchase
                else
                    return 4;
            }
            else if (type == "fuel")
            {
                //return for player not having enough currency to purchase
                if (totalPrice > SpaceBucks)
                    return 1;
                //return for player not having enough space to buy that much fuel
                else if (ammountSelected > FuelSpaceAvailable)
                    return 2;
                //return for player having enough money and space to purchase fuel
                else if (totalPrice <= SpaceBucks && ammountSelected <= FuelSpaceAvailable)
                    return 3;
                //Something went wrong return a 4 to deny player from purchase.
                else
                    return 4;

            }
            //erronius buy type return 4 to not allow the buy
            else return 4;
        }

        //Check if CanFly

        //Fly.  

        //Pass Fight Options.  Passes Fight Properties.

        //Shop.  Passes Resources.

    }
}
