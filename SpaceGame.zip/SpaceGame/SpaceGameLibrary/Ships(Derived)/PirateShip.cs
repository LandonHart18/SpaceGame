﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGame
{
    class PirateShip : Ships
    {
        public PirateShip()
        {
            this.HitPoints = 100;
            this.Weapon = 1;
            this.Engine = 1;            
        }

        /// <summary>
        /// All player input needs to be moved to the Controller otherwise there will be a disconnect in display. -Aaron
        /// </summary>

        //Calculate Difficulty of Ship and adjust Properties.

        //Pass Fight Properties.        
    }
}
