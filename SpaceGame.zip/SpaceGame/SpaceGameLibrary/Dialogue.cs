﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceGameLibrary
{
    public class Dialogue
    {
        /// <summary>
        ///Used for all the dialogue in the game.  The only class that needs to access this is the Writer. -Aaron. 
        /// </summary>
        
        //ASCII for title.
        public string Title => "$$$$$$$$\\ $$\\                       $$$$$$$$\\                                     $$\\                               \n\\__$$  __|$$ |                      \\__$$  __|                                    $$ |                              \n   $$ |   $$$$$$$\\   $$$$$$\\           $$ | $$$$$$\\  $$$$$$\\ $$\\    $$\\  $$$$$$\\  $$ | $$$$$$\\   $$$$$$\\   $$$$$$$\\ \n   $$ |   $$  __$$\\ $$  __$$\\          $$ |$$  __$$\\ \\____$$\\\\$$\\  $$  |$$  __$$\\ $$ |$$  __$$\\ $$  __$$\\ $$  _____|\n   $$ |   $$ |  $$ |$$$$$$$$ |         $$ |$$ |  \\__|$$$$$$$ |\\$$\\$$  / $$$$$$$$ |$$ |$$$$$$$$ |$$ |  \\__|\\$$$$$$\\  \n   $$ |   $$ |  $$ |$$   ____|         $$ |$$ |     $$  __$$ | \\$$$  /  $$   ____|$$ |$$   ____|$$ |       \\____$$\\ \n   $$ |   $$ |  $$ |\\$$$$$$$\\          $$ |$$ |     \\$$$$$$$ |  \\$  /   \\$$$$$$$\\ $$ |\\$$$$$$$\\ $$ |      $$$$$$$  |\n   \\__|   \\__|  \\__| \\_______|         \\__|\\__|      \\_______|   \\_/     \\_______|\\__| \\_______|\\__|      \\_______/ ";

        //Needs to be centered under the title.  Will need to find the setting/syntax for console size to ensure it works on all displays.
        public string GameStart => "Press ENTER to begin your journey!!";

        //This should be the only line on the End screen besides the user pressing enter to continue.
        //Possible ASCII Art
        //--Landon
        public string End()
        {
            string End = "Game Over! :(";
            return End;
        }



        /*void FlyASCII()
        {
            //If we have any.
        }

        //Text i have so far for the Ship Console Screen.
        //Possible ASCII Art
        //--Landon 
        public void ShipConsoleText()
        {
            string InitialTHQText = "You’re greeted by a message from Traveler HQ stating the following “Hello Traveler-117, this is your new identification number. " +
                                    "\nYou will use this to dock at Traveler HQ and sell the goods you have acquired from your travels. Resources are dwindling, " +
                                    "\nthe future is grim. Earth is void of its own resources and is paying highly for goods from other planets. They need all they " +
                                    "\ncan get, and you are a vital part in keeping earth alive. Remember without “The Travelers” earth would have died off long ago, you are a Traveler…";

            string Mission = "Traveler-117 your mission is below and other important information you should know." +
                             "\n1.Mercury sells metals" +
                             "\n2.Venus sells Aphrodisiacs." +
                             "\n3.Mars sells food." +
                             "\n4.Earth buys the goods from other planets." +
                             "\n5.Moon Base is where you can purchase upgrades for your ship." +
                             "\n6.Titan sells water.7.Europa sells Metals, Aphrodisiacs, Food, and Water." +
                             "\n8.Task as Traveler - 117 is too buy as many resources as possible and transport them back to earth and sell it for as much profit as possible." +
                             "\nHopefully one day you can buy your retirement and live a peaceful life on Europa like every Travelers dream.";

            string ResourceFuel = "Fuel:";
            string ResourceFood = "Food:";
            string ResourceWater = "Water:";
            string ResourceMetals = "Metal:";
            string ResourceAphrodisiacs = "Aphrodisiacs:";
            string Credits = "Credits:";

            string ShipStatusWpnLvl = "Weapon Level:";
            string ShipStatusEngLvl = "Engine Level:";
            string ShipStatusHullHP = "Hull Hit-points:";
            string ShipStatusShieldHP = "Shield Hit-points:";


            string PlanetSelection = "Please select which planet you wish to travel too:" +
                                     "\n1. Mercury" +
                                     "\n2. Venus" +
                                     "\n3. Mars" +
                                     "\n4. Earth" +
                                     "\n5. Moon Base" +
                                     "\n6. Titan" +
                                     "\n7. Europa";
        }

        //Text i have so far for Market/Selling/Buying/Planet Screen-Mercury.
        //Possible ASCII Art
        //--Landon 
        public void MercuryText()
        {
            string MercuryMove = "You have chosen Mercury, Engaging Warp Drive!";
            string MercuryMoveDock = "You come out of warp drive once you are close to Mercury. You start heading to the docking station.";
            string MercuryDocking = "You dock at the station and step out your ship and head towards the industrial market.";
            string MercuryMarket = "The door slides open to the industrial market with multiple vendors, but a certain store catches your eye. A beaten-up looking stand’s " +
                                   "\noutside of his shop, he sees you and shouts “Welcome to Mercury! Come! Come! I see you are a Traveler! I will give you great discount " +
                                   "\nat my store if you come to me and only me!” ";
            string MercuryAgree = "You agree and ask to see his stock.";
            string MercuryResource = "I have {x} metal for {x} amount per metal.";
            string MercuryResourceSelect = "Do you want to buy metal, Yes or No?";
            string MercuryResourceSelectBuy = "Please select how much metal you want to buy:";
            string MercuryBuy = "You buy {x} amount of metals for {x} credits.";
            string MercuryGuaranteedMsg = "Hello 117 nice to see you’re not dead! HAHAHAHA!!! What can I do for you? More of the same?";

        }

        //Text i have so far for Market/Selling/Buying/Planet Screen-Venus.
        //Possible ASCII Art
        //--Landon 
        public void VenusText()
        {
            string VenusMove = "You have chosen Venus, Engaging Warp Drive!";
            string VenusMoveDock = "You come out of warp drive once you are close to Venus. You start heading to the docking station.";
            string VenusDocking = "You dock at the station and step out of your and head towards the Aphrodisiacs market.";
            string VenusMarket = "The door slides open to the Aphrodisiacs market with multiple vendors, but a you’re here for a particular store you already had in mind. " +
                                 "\nYour friend Traveler-118 vouched for this store. You find an old woman blind as a bat looking your way and says “Welcome to my store! " +
                                 "\nI can already tell 118 sent you… no one shops here but him! HAHAHA!";
            string VenusAgree = "You ask to see her stock.";
            string VenusResource = "I have {x} Aphrodisiacs for {x} amount per Aphrodisiac.";
            string VenusResourceSelect = "Do you want to buy Aphrodisiacs, Yes or No?";
            string VenusResourceSelectBuy = "Please select how much Aphrodisiacs you want to buy:";
            string VenusBuy = "You buy {x} amount of Aphrodisiacs for {x} credits.";
            string VenusGuaranteedMsg = "Hello 117 nice to see you’re still kick’n and earth still needs to keep populating!!";
        }

        //Text i have so far for Market/Selling/Buying/Planet Screen-Mars.
        //Possible ASCII Art
        //--Landon 
        public void MarsText()
        {
            string MarsMove = "You have chosen Mars, Engaging Warp Drive!";
            string MarsMoveDock = "You come out of warp drive once you are close to Mars. You start heading to the docking station.";
            string MarsDocking = "You dock at the station and step out your ship and head towards the Farmer's market.";
            string MarsMarket = "The door slides open you see nothing but vast lush fields of grains, fruit, and vegetables. You walk to the Farmer’s Market and approach the " +
                                "\nfirst store you see. You are greeted by a family stock their shelves. The husband asks, 'what can I do you for you traveler?'";
            string MarsAgree = "You ask to see his stock.";
            string MarsResource = "I have {x} Food for {x} amount per Food.";
            string MarsResourceSelect = "Do you want to buy Food, Yes or No?";
            string MarsResourceSelectBuy = "Please select how much Food you want to buy:";
            string MarsBuy = "You buy {x} amount of Food for {x} credits.";
            string MarsGuaranteedMsg = "Hello Mr. 117, nice to see you again! Please stop by to get restocked on food.";
        }

        //Text i have so far for Market/Selling/Buying/Planet Screen-Earth.
        //Possible ASCII Art
        //--Landon 
        public void EarthText()
        {
            string EarthMove = "You have chosen Earth, Engaging Warp Drive!";
            string EarthMoveDock = "You come out of warp drive once you are close to Earth. You start heading to The Travelers HQ station.";
            string EarthDocking = "You dock at your assigned bay #117 and step of your ship and head towards your best robot friend you ever had! You call him Ristt (Robot I Sell Things To).";
            string EarthGuaranteedRistt = "Ristt begins talking to you 'Hello 117 hope your travels have been good! What have you got for me today?'";
            string EarthResourceSelect = "Which resource do you wish to sell?" +
                                         "\n1. Food" +
                                         "\n2. Water" + 
                                         "\n3. Metal" +
                                         "\n4. Aphrodisiacs";

            string EarthResourceSelectSell = "Please select how much {x} you want to sell:";
            string EarthSell = "You sold {x} amount of {x} for {x} credits.";
            string EarthLeavingMsg = "Ristt begins to say his programmed line after finishing a transaction 'Remember without 'The Travelers' earth would have died off long ago, you are a Traveler…'";
        }

        //Text i have so far for Market/Selling/Buying/Planet Screen-MoonBase.
        //Possible ASCII Art
        //--Landon 
        public void MoonBaseText()
        {
            string MoonBaseMove = "You have chosen MoonBase, Engaging Warp Drive!";
            string MoonBaseMoveDock = "You come out of warp drive once you are close to MoonBase. You start heading to the upgrade station.";
            string MoonBaseDockingMsg = "Once docking is complete at the upgrade station your ships console begins displaying what upgrades are available. At the same time the stations security system " +
                                     "\nLiberty Prime comes over your ships comms and starts saying the generic message it says every time 'You are now under watch and guard from Liberty Prime, " +
                                     "\nplease follow this rules, any deviation from them will be viewed as hostile and you will be obliterated.' " +
                                     "\n1. Please remain in your ship at all times while docked. " +
                                     "\n2. While entering or leaving shields and weapons will remain powered down. Remember Liberty Prime is always watching.";
            string MoonBaseUpgradeSelect = "Please select which part of the ship you wish to upgrade:" +
                                           "\n1. Weapon" +
                                           "\n2. Engine" + 
                                           "\n3. Hull-Points" + 
                                           "\n4. Shield-Points";
            string MoonBaseResourceSelectBuy = "Please select which ship upgrade you want to buy:";
            string MoonBaseBuy = "You bought {x} upgrade for {x} credits.";
            string MoonBaseLeavingMsg = "Liberty Prime comes over your ships comms again saying 'Upgrades have been installed, please un-dock and come again.'";
        }

        //Text i have so far for Market/Selling/Buying/Planet Screen-Titan.
        //Possible ASCII Art
        //--Landon 
        public void TitanText()
        {
            string TitanMove = "You have chosen Titan, Engaging Warp Drive!";
            string TitanMoveDock = "You come out of warp drive once you are close to Titan. You start heading to the docking station.";
            string TitanDocking = "You dock at the station and step of your ship and head towards the water market.";
            string TitanMarket = "The door slides open to the water market and you begin trying to find a store that looks like it has not been rusted to the core. " +
                                 "\nYou eventually find a small wooden shack with a sign out front that says “Best water in Titan, all natural from a spring” intrigued you walk in. " +
                                 "\nYou find a short man crawling out from under this pump that leads to the fake spring he as built around it. You chuckle…";
            string TitanAgree = "You ask to see his stock.";
            string TitanResource = "I have {x} water for {x} amount per gallon of water.";
            string TitanResourceSelect = "Do you want to buy water, Yes or No?";
            string TitanResourceSelectBuy = "Please select how much water you want to buy:";
            string TitanBuy = "You buy {x} gallons of water for {x} credits.";
            string TitanGuaranteedMsg = "Remember to stop by and refill, its fresh and all natural!";
        }

        //Text i have so far for Market/Selling/Buying/Planet Screen-Europa.
        //Possible ASCII Art
        //--Landon 
        public void EuropaText()
        {
            string EuropaMove = "You have chosen Europa, Engaging Warp Drive!";
            string EuropaMoveDock = "You come out of warp drive once you are close to Europa, a few moments later you receive an alert on your dashboard. It is a blockade and they are asking " +
                                    "\nyou to present your Traveler ID. You have heard stories about Europa and how guarded it was this is your first time being here. They scan your ship in " +
                                    "\nits entirety and issue you a traveler visa to be able to get through the blockade without they would open fire and destroy you.";
            string EuropaDocking = "You dock at the station and step of and head towards the market.You begin to notice is how clean and pristine everything looks. You have never been this " +
                                   "\nfar out, and you begin to remember the stories you have heard about this place. This planet is the richest and most well terraformed planet, Mars does " +
                                   "\nnot even come close. You can get anything here. You also remember why the travelers call this place Paradise. The only way to get on this planet is to " +
                                   "\nbuy your way in or be a Traveler who buys retirement.";
            string EuropaMarket = "You make your way to Traveler market which is the only area you are allowed to be in with the Traveler visa. Its one big building with multiple Automated " +
                                  "\nrobots. You go the closest one and begin to buy.";
            string EuropaRobotDialog = "The robot begins to rattle off what the market has in stock.";
            string EuropaResources = "I have {x} metals for {x} amount per metal." +
                                     "I have {x} Aphrodisiacs for {x} amount per Aphrodisiac." +
                                     "I have {x} Food for {x} amount per Food." +
                                     "I have {x} water for {x} amount per gallon of water.";
            string EuropaResourceSelect = "Which resource do you wish to buy?" +
                                          "\n1. Food" +
                                          "\n2. Water" +
                                          "\n3. Metal" +
                                          "\n4. Aphrodisiacs"; ;
            string EuropaResourceSelectBuy = "Please select how much {x} you want to buy:";
            string EuropaBuy = "You buy {x} amount of {x} for {x} credits.";
            string EuropaGuaranteedMsg = "Hello Traveler-117, please proceed to your assigned area.";
        }

        //Text i have so far for Combat/Battle Text.
        //Possible ASCII Art
        //--Landon 
        public void BattleText()
        {
            string PiratesStartEncounter = "YOU’VE ENCOUNTERED SPACE PIRATES!";
            string PirateDialog = "Hahahaha look fellas! The Traveler is all alone… prepare to die Traveler scum!";
            string PirateHit = "Pirate has hit you for {x}, your HP is now {x}.";
            string PirateShieldHit = "Pirate has hit your shield for {x}, shield is now at {x}.";
            string PirateWin = "You have been defeated in battle… the Travelers will put your name on the wall of hero’s. Game Over!";


            string TravelerWin = "You have defeated the Pirate Ship, you have received {x} Metals, {x} Aphrodisiacs, {x} Food, and {x} Water from the wreckage of the ship!";
            string TravelerHit = "You hit the Pirate for {x}, his HP is now {x}.";
            string TravelerFlee = "You have decided to flee to keep your life and resources!";
            string ShieldActivate = "Your shields are active, they’re at {x} HP!";
            string NoShield = "There is not enough power to activate shields again!";
            string RepairShip = "You repaired you ship!";
            string NoRepair = "You don't need to repair your ship right now...";
            string ShipAlreadyRepaired = "You've already repaired your ship as much as you could! Your HP is now at {x}!";


            string FightStart = "You have decided to fight and rid the solar system of pirate scum!";
            string FightMenu = "Select an option: 1.Fight! 2.Activate shields! 3.Repair ship! 4.Escape!";
        }

        //Text for continuing the game.
        //--Landon 
        public string Continue()
        {
            string action = "Press enter to continue!";
            return action;
        }*/

    }
}
