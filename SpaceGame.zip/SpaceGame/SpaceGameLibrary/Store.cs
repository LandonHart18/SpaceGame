﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;


namespace SpaceGame
{
    public class Store
    {
        //buying fuel from planets, takes in shop type (buy/sell) and store sell and buy price from planet
        public void Fuel(string type, int storeSellPrice, int storeBuyPrice)
        {
            PlayerShip ship = new PlayerShip();
            if (type == "sell")
            {
                WriteLine("How much fuel would you like to sell?");
                int selection = int.Parse(ReadLine());
                if (ship.Fuel < selection)
                    WriteLine("You don't even have that much fuel to sell!");
                else {
                    WriteLine("Are you sure you want to sell your fuel?");
                    string answer = ReadLine().ToLower();
                    if (answer == "yes")
                    {
                        ship.Fuel -= selection;
                        ship.SpaceBucks += (selection * storeBuyPrice);
                    }
                }
                
            }
            else
            {
                WriteLine("How much would you like to buy?");
                int ammount = int.Parse(ReadLine());
                int result = ship.CanBuy("goods", ammount, storeSellPrice);
                switch (result)
                {
                    case 1:
                        WriteLine("You can't afford this!");
                        break;

                    case 2:
                        WriteLine("Your ship doesn't even have the space for this!");
                        break;

                    case 3:
                        WriteLine("Are you sure you want to buy this?");
                        string check = ReadLine().ToLower();
                        if (check == "yes")
                        {
                            ship.Fuel += ammount;
                            ship.SpaceBucks -= (ammount * storeSellPrice);
                            WriteLine("Thank you for your buisness");
                            break;
                        }
                        WriteLine("Come back when you've made up your mind!");
                        break;

                    default:
                        WriteLine($"There's currently an issue with our registers, come back later");
                        break;
                }
            }
        }
        public void TradeFuel()
        {

        }
        public void Food(string type, int storeSellPrice, int storeBuyPrice)
        {
            PlayerShip ship = new PlayerShip();
            if (type == "sell")
            {
                WriteLine("How much food would you like to sell?");
                int selection = int.Parse(ReadLine());
                if (ship.FoodGoods < selection)
                    WriteLine("You don't even have that much food to sell!");
                else
                {
                    WriteLine("Are you sure you want to sell your food?");
                    string answer = ReadLine().ToLower();
                    if (answer == "yes")
                    {
                        ship.FoodGoods -= selection;
                        ship.SpaceBucks += (selection * storeBuyPrice);
                    }
                }
            }
            else
            {
                WriteLine("How much would you like to buy?");
                int ammount = int.Parse(ReadLine());
                int result = ship.CanBuy("goods", ammount, storeSellPrice);
                switch (result)
                {
                    case 1:
                        WriteLine("You can't afford this!");
                        break;

                    case 2:
                        WriteLine("Your ship doesn't even have the space for this!");
                        break;

                    case 3:
                        WriteLine("Are you sure you want to buy this?");
                        string check = ReadLine().ToLower();
                        if (check == "yes")
                        {
                            ship.FoodGoods += ammount;
                            ship.SpaceBucks -= (ammount * storeSellPrice);
                            WriteLine("Thank you for your buisness");
                            break;
                        }
                        WriteLine("Come back when you've made up your mind!");
                        break;

                    default:
                        WriteLine($"There's currently an issue with our registers, come back later");
                        break;
                }
            }
        }
        public void TradeFood()
        {

        }
        public void Water(string type, int storeSellPrice, int storeBuyPrice)
        {
            PlayerShip ship = new PlayerShip();
            if (type == "sell")
            {
                WriteLine("How much water would you like to sell?");
                int selection = int.Parse(ReadLine());
                if (ship.WaterGoods < selection)
                    WriteLine("You don't even have that much water to sell!");
                else
                {
                    WriteLine("Are you sure you want to sell your water?");
                    string answer = ReadLine().ToLower();
                    if (answer == "yes")
                    {
                        ship.WaterGoods -= selection;
                        ship.SpaceBucks += (selection * storeBuyPrice);
                    }
                }
            }
            else
            {
                WriteLine("How much would you like to buy?");
                int ammount = int.Parse(ReadLine());
                int result = ship.CanBuy("goods", ammount, storeSellPrice);
                switch (result)
                {
                    case 1:
                        WriteLine("You can't afford this!");
                        break;

                    case 2:
                        WriteLine("Your ship doesn't even have the space for this!");
                        break;

                    case 3:
                        WriteLine("Are you sure you want to buy this?");
                        string check = ReadLine().ToLower();
                        if (check == "yes")
                        {
                            ship.WaterGoods += ammount;
                            ship.SpaceBucks -= (ammount * storeSellPrice);
                            WriteLine("Thank you for your buisness");
                            break;
                        }
                        WriteLine("Come back when you've made up your mind!");
                        break;

                    default:
                        WriteLine($"There's currently an issue with our registers, come back later");
                        break;
                }
            }
        }

        public void TradeWater()
        {

        }

        public void Metals(string type, int storeSellPrice, int storeBuyPrice)
        {
            PlayerShip ship = new PlayerShip();
            if (type == "sell")
            {
                WriteLine("How much metal would you like to sell?");
                int selection = int.Parse(ReadLine());
                if (ship.MetalsGoods < selection)
                    WriteLine("You don't even have that much metal to sell!");
                else
                {
                    WriteLine("Are you sure you want to sell your metal?");
                    string answer = ReadLine().ToLower();
                    if (answer == "yes")
                    {
                        ship.MetalsGoods -= selection;
                        ship.SpaceBucks += (selection * storeBuyPrice);
                    }
                }
            }
            else
            {
                WriteLine("How much would you like to buy?");
                int ammount = int.Parse(ReadLine());
                int result = ship.CanBuy("goods", ammount, storeBuyPrice);
                switch (result)
                {
                    case 1:
                        WriteLine("You can't afford this!");
                        break;

                    case 2:
                        WriteLine("Your ship doesn't even have the space for this!");
                        break;

                    case 3:
                        WriteLine("Are you sure you want to buy this?");
                        string check = ReadLine().ToLower();
                        if (check == "yes")
                        {
                            ship.MetalsGoods += ammount;
                            ship.SpaceBucks -= (ammount * storeSellPrice);
                            WriteLine("Thank you for your buisness");
                            break;
                        }
                        WriteLine("Come back when you've made up your mind!");
                        break;

                    default:
                        WriteLine($"There's currently an issue with our registers, come back later");
                        break;
                }
            }
        }

        public void Trademetals()
        {

        }

        public void Aphrodisiac(string type, int storeSellPrice, int storeBuyPrice)
        {
            PlayerShip ship = new PlayerShip();
            if (type == "sell")
            {

                WriteLine("How much metal would you like to sell?");
                int selection = int.Parse(ReadLine());
                if (ship.AphrodisiacGoods < selection)
                    WriteLine("You don't even have that much metal to sell!");
                else
                {
                    WriteLine("Are you sure you want to sell your metal?");
                    string answer = ReadLine().ToLower();
                    if (answer == "yes")
                    {
                        ship.AphrodisiacGoods -= selection;
                        ship.SpaceBucks += (selection * storeBuyPrice);
                    }
                }


            }
            else
            {
                WriteLine("How much would you like to buy?");
                int ammount = int.Parse(ReadLine());
                int result = ship.CanBuy("goods", ammount, storeSellPrice);
                switch (result)
                {
                    case 1:
                        WriteLine("You can't afford this!");
                        break;

                    case 2:
                        WriteLine("Your ship doesn't even have the space for this!");
                        break;

                    case 3:
                        WriteLine("Are you sure you want to buy this?");
                        string check = ReadLine().ToLower();
                        if (check == "yes")
                        {
                            ship.AphrodisiacGoods += ammount;
                            ship.SpaceBucks -= (ammount * storeSellPrice);
                            WriteLine("Thank you for your buisness");
                            break;
                        }
                        WriteLine("Come back when you've made up your mind!");
                        break;

                    default:
                        WriteLine($"There's currently an issue with our registers, come back later");
                        break;
                }
            }
        }

        public void TradeAphrodisiac()
        {

        }
    }
}
