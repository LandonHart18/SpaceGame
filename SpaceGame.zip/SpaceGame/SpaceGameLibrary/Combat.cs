﻿using SpaceGameLibrary;
using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Runtime.CompilerServices;
using System.Text;
using static System.Console;

namespace SpaceGame
{
    public class Combat
    {
        PlayerShip player = new PlayerShip();
        PirateShip pirate = new PirateShip();
        Dialogue dialogue = new Dialogue();

        /// <summary>
        /// All player input needs to be moved to the Controller otherwise there will be a disconnect in display. -Aaron
        /// </summary>
        public void FightMenu()
        {

            //BattleText();
            Console.WriteLine("What want do?");//testing
            Console.WriteLine("1. fight 2. shield 3. repair 4. flee");
            string input = Console.ReadLine();
            switch (input)
            {
                case "1": 
                    Fight();
                    break;
                case "2":
                    Shield();
                    break;
                case "3": 
                    RepairShip();
                    break;
                case "4":
                    Flee();
                    break;

            }
        }
        int CalculatePlayerDamage()
        {
            int playerDamage = player.Weapon;

            Random RandomRNG = new Random();
            int chance = RandomRNG.Next(1, 101);
            int critChance = RandomRNG.Next(1, 101);

            if (chance >= 33 && chance <= 65)
            {
                playerDamage += 1;
            }
            else if (chance < 33)
            {
                playerDamage += 2;
            }
            else
            {
                playerDamage += 3;
            }
            if (critChance < 11)
            {
                playerDamage *= 2;
                Console.WriteLine("\nYou hit a crit!");
            }
            return playerDamage;
        }
        int CalculatePirateDamage()
        {
            int pirateDamage = pirate.Weapon;

            Random RandomRNG = new Random();
            int chance = RandomRNG.Next(1, 101);

            if (chance >= 33 && chance <= 65)
            {
                pirateDamage += 1;
            }
            else if (chance < 33)
            {
                pirateDamage += 2;
            }
            else
            {
                pirateDamage += 3;
            }
            return pirateDamage;
        }
        void PlayerHit()
        {
            int playerDamage = CalculatePlayerDamage();
            pirate.HitPoints -= playerDamage;
            Console.WriteLine($"You hit for {playerDamage} and now he's at {pirate.HitPoints}");//test
            //BattleText();
            if (pirate.HitPoints <= 0)
            {
                Flee();
            }
        }
        void PirateHit()
        {
            int pirateDamage = CalculatePirateDamage();

            if (player.Shield <= 0)
            {
                //BattleText();
                player.HitPoints -= pirateDamage;
                Console.WriteLine($"You get hit for {pirateDamage} now you're at {player.HitPoints}");//test

            }
            else if (player.Shield > 0)
            {
                player.Shield -= pirateDamage;
                //BattleText();

                if (player.Shield > 0)
                {
                    //BattleText();
                    Console.WriteLine($"Your shield gets popped for {pirateDamage} now your shield is at {player.Shield}");//test

                }
                else
                {
                    //BattleText();
                    Console.WriteLine("You shield is dead");
                }
            }
            if (player.HitPoints <= 0)
                Flee();
            
        }
        void Shield()
        {
            ActivateShield();
            PirateHit();
            FightMenu();
        }
        void Fight()
        {
            PlayerHit();
            PirateHit();
            FightMenu();
        }
        void FleeInFight()//need code
        {
            FleeChance();
        }
        int FleeChance()//need code
        {
            return;
        }

        void RepairShip()
        {
            RepairYourShip();
            PirateHit();
            FightMenu();
        }
        void RepairYourShip()
        {
            if (player.HitPoints >= player.MaxHitPoints)
            {
                //BattleText();
            }
            else if (player.Repair <= 0)
            {
                //BattleText();
            }
            else
            {
                while (player.Repair > 0 && player.HitPoints < player.MaxHitPoints)
                {
                    //BattleText();
                    Console.WriteLine("You repair");//test
                    if (player.HitPoints + player.RepairValue > player.MaxHitPoints)
                    {
                        player.HitPoints = player.HitPoints + (-(player.HitPoints - player.MaxHitPoints));
                        player.Repair--;
                    }
                    else
                    {
                        player.HitPoints += player.RepairValue;
                        player.Repair--;
                    }
                    //Battle.Text();
                    Console.WriteLine($"Your HP is now at {player.HitPoints}");//test
                }
            }
        }
        void ActivateShield()
        {
            if (player.ShieldQuantity > 0)
            {
                //BattleText();
                Console.WriteLine($"Shield is active\n");//test
                player.ShieldQuantity--;
                player.Shield += player.ShieldMaxPower;
                Console.WriteLine($"Shield will absorb {player.Shield}");//test
            }
            else
            {
                Console.WriteLine("Not enough power to use shield");//test
                //BattleText();
            }
        }






        ///// <summary>
        ///// Combat Cleanup and merging.
        ///// </summary>
        //public void PlayerHitOriginal()
        //{
        //    CalculatePlayerDamage();
        //    Write("You hit the Pirate for a ");
        //    Console.ForegroundColor = ConsoleColor.Red;
        //    Write($"{hit}");
        //    Console.ForegroundColor = ConsoleColor.Gray;
        //    Write($"! His HP is now ");
        //    Console.ForegroundColor = ConsoleColor.Red;
        //    Write($"{PirateShip.HitPoints - hit}\n");
        //    Console.ForegroundColor = ConsoleColor.Gray;
        //    BattleText(int 1, hit)

        //    PirateShip.HitPoints -= hit;
        //}//This is used whenever the player gets to hit the Pirate
        //public void SpacePirateHit()//Figure out how to get the damage from the pirateDamageDamage method -- Serghei
        //{
        //    if (shield <= 0)
        //    {
        //        CalculatePirateDamage();
        //        Write("\nBad guy hits you for a ");
        //        Console.ForegroundColor = ConsoleColor.Blue;
        //        Write($"{hit}");
        //        Console.ForegroundColor = ConsoleColor.Gray;
        //        Write($"! Your HP is now ");
        //        Console.ForegroundColor = ConsoleColor.Blue;
        //        Write($"{player.HitPoints - hit}\n");
        //        Console.ForegroundColor = ConsoleColor.Gray;

        //        PlayerShip.Hit -= hit;
        //    }
        //    else if (shield > 0)
        //    {
        //        CalculatePirateDamage();
        //        shield -= hit;

        //        Write("\nBad guy hits you for a ");
        //        Console.ForegroundColor = ConsoleColor.Cyan;
        //        Write($"{hit}");
        //        Console.ForegroundColor = ConsoleColor.Gray;
        //        if (shield > 0)
        //        {
        //            Write($"! Your shield absorbs the damage, your shield is now at ");
        //            Console.ForegroundColor = ConsoleColor.Cyan;
        //            Write($"{shield}\n ");
        //            Console.ForegroundColor = ConsoleColor.Gray;
        //        }
        //        else
        //        {
        //            WriteLine(" Your shield dissipates into nothing");
        //        }
        //    }
        //}
        //public void ActivateShield2()
        //{
        //    if (ShieldQuantity == 0)
        //    {
        //        WriteLine("Your shields are active!\n");
        //        Console.ForegroundColor = ConsoleColor.Cyan;
        //        WriteLine($"Your shield will absorb {shield + 10} damage\n");
        //        Console.ForegroundColor = ConsoleColor.Gray;
        //        ShieldQuantity++;
        //        shield += 10;
        //    }
        //    else
        //    {
        //        Console.WriteLine("\nThere is not enough power to activate shields!");
        //        SpacePirateHit();
        //    }
        //}
        //public void RepairShip2()
        //    {
        //        if (player.HitPoints >= 20)
        //        {
        //            WriteLine("You don't need to repair your ship right now...");
        //        }
        //        else if (repair <= 0)
        //        {
        //            WriteLine("You've already repaired your ship as much as you could!");
        //        }
        //        else
        //        {
        //            while (repair > 0 && player.HitPoints < 20)
        //            {
        //                WriteLine("You repair your ship!");
        //                if (player.HitPoints >= 10)
        //                {
        //                    player.HitPoints = player.HitPoints + (-(player.HitPoints - 20));

        //                    repair -= repair;

        //                }
        //                else
        //                {
        //                    player.HitPoints += 10;
        //                    repair -= repair;

        //                }
        //                Write($"Your HP is now at ");
        //                Console.ForegroundColor = ConsoleColor.Blue;
        //                Write($"{player.HitPoints}");
        //                Console.ForegroundColor = ConsoleColor.Gray;
        //            }
        //        }
        //        int hitz = 0;
        //    }//Repairs ship for a flat 10HP currently, we can work on a way to upgrade this perk -- Serghei
        //public void Fighting()//this method will hold the entire fight until someone reaches 0 HP or you escape -- Serghei
        //    {
        //        WriteLine("You encountered Space Pirates!\n");

        //        while (PirateShip.HitPoints > 0 && player.HitPoints > 0) // This loop keeps going until someone is dead or escapes -- Serghei
        //        {
        //            WriteLine("\nSelect an option\n1.Fight!\n2.Activate shields\n3.Repair ship\n4.Escape!");
        //            string input = Console.ReadLine();
        //            switch (input)
        //            {
        //                case "1":
        //                    PlayerHit();
        //                    SpacePirateHit();
        //                    break;
        //                case "2":
        //                    ActivateShield();
        //                    SpacePirateHit();
        //                    break;
        //                case "3":
        //                    RepairShip();
        //                    SpacePirateHit();
        //                    break;

        //                case "4":
        //                    WriteLine("There's no code for that yet.. lol");
        //                    break;
        //            }
        //        }
        //        //end fight 
        //    }


        //}
    }
}
    
