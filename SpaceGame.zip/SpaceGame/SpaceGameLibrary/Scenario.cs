﻿using SpaceGameLibrary;
using SpaceGame;
using System;
using System.Collections.Generic;
using System.Text;


namespace SpaceGame
{
    class Scenario
    {
        PlayerShip player = new PlayerShip();
        Combat combat = new Combat();
        Dialogue dialogue = new Dialogue();        

        Planets planets = new Planets();

        /// <summary>
        /// All player input needs to be moved to the Controller otherwise there will be a disconnect in display.
        /// </summary>

        void Fly()
        {            
            //current location
            //destination
            //fuel 

            //Fuel calculation.
            PirateEncounter();



        }

        void PirateEncounter()
        {
            //Percentage to land successfully.

            //Call on Fight Menu
        }

        
        //Fly Method.

        //calculate encounter roll.

        //Retire Method.       

        //Game Over Method.
    }
}
